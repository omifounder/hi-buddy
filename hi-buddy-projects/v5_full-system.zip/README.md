# v5_full-system

Full desktop + mobile integration, cloud fallback

_No model weights included._
