# v3_quant-gpu

Integrated quantized GPU model loading (Gemma, Wav2Vec2, AffectNet placeholders)

_No model weights included._
