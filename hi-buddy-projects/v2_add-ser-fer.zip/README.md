# v2_add-ser-fer

Added real SER/FER model loaders (stubbed weights)

_No model weights included._
