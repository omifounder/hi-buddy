# v4_mobile-support

Added Capacitor mobile client hooks

_No model weights included._
