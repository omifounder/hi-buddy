# v1_mvp

Initial MVP with WebRTC + mock SER/LLM

_No model weights included._
