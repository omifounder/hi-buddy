# server with SER integration placeholder
