// Preload script hooks
