# Desktop Assistant Starter Repo
Instructions to run Electron frontend and Python backend.
