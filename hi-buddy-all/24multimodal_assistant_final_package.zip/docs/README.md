See the PPTX in this folder for the 1-hour walkthrough.
