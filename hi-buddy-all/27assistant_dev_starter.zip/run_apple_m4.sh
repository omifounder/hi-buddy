#!/usr/bin/env bash
# Run script for Apple M4 - usage: ./run_apple_m4.sh [mvp|full] [desktop|mobile|multiplatform]
MODE=${1:-mvp}
TARGET=${2:-multiplatform}
echo "Running $MODE for $TARGET"

python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

if [ "$MODE" = "mvp" ]; then
  if [ "$TARGET" = "desktop" ]; then python3 code/desktop/mvp/server.py; exit 0; fi
  if [ "$TARGET" = "mobile" ]; then python3 code/mobile/mvp/server.py; exit 0; fi
  python3 code/multiplatform/mvp/server.py; exit 0
else
  if [ "$TARGET" = "desktop" ]; then python3 code/desktop/full/server.py; exit 0; fi
  if [ "$TARGET" = "mobile" ]; then python3 code/mobile/full/server.py; exit 0; fi
  python3 code/multiplatform/full/server.py; exit 0
fi
