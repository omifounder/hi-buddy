\
@echo off
REM Run script for Windows (PowerShell recommended) - accepts args: full|mvp and desktop|mobile|multiplatform
set MODE=%1
set TARGET=%2
if "%MODE%"=="" set MODE=mvp
if "%TARGET%"=="" set TARGET=multiplatform
echo Running %MODE% for %TARGET%

python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt

if "%MODE%"=="mvp" (
    if "%TARGET%"=="desktop" python code\desktop\mvp\server.py & goto :eof
    if "%TARGET%"=="mobile" python code\mobile\mvp\server.py & goto :eof
    python code\multiplatform\mvp\server.py & goto :eof
) else (
    if "%TARGET%"=="desktop" python code\desktop\full\server.py & goto :eof
    if "%TARGET%"=="mobile" python code\mobile\full\server.py & goto :eof
    python code\multiplatform\full\server.py & goto :eof
)
