WebRTC Live SER prototype. Run uvicorn server:app and open ui_webrtc.html
